export default ({ width, height, x, y }) => ({
  width,
  height,
  x,
  y,
});
